
python run_search.py ../Data/a_tiles_easy.txt 10 4 | set-content a_easy.out
python run_search.py ../Data/b_tiles_medium.txt 10 4 | set-content b_medium.out
python run_search.py ../Data/c_tiles_hard.txt 10 4 | set-content c_hard.out
python run_search.py ../Data/d_tiles_nightmare.txt 10 5 | set-content d_nightmare.out

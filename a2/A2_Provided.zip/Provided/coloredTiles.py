# CMPT 317: Colored Tiles Problem Starter code

import math as math

class State(object):
    """
       Note: Each state will need to store the action that created that state
       in a class variable called "action" to get full use out of scripts such
       as see_solutions.py
    """
    def __init__(self):
        """
        Initialize a new State object.
        
        """
        self.action = 'Initial state'
        #TODO: implement this function.  Add parameters as needed.

    def __str__(self):
        """ A string representation of the State """
        #TODO: implement this function. 
        return ""

    def __eq__(self, other):
        """ Defining this function allows states to be compared
        using the == operator """    
        #TODO: implement this function.         
        return False
        
    

class Problem(object):
    """The Problem class defines aspects of the problem.
       One of the important definitions is the transition model for states.
       To interact with search classes, the transition model is defined by:
            is_goal(s): returns true if the state is the goal state.
            actions(s): returns a list of all legal actions in state s
            result(s,a): returns a new state, the result of doing action a in state s

    """

    def __init__(self, nrows, ncols, start=None):
        """ The problem is defined by an initial grid of tiles.
        
            :param nrows: number of rows in the tile puzzle
            :param ncols: number of columns in the tile puzzle
            :param start: a list of strings where each character is R or G.  Each string represents one row of the grid
        """
        #TODO: implement this function. You can change the parameters if you really want, but then you will have to change the calls in run_search.py
        return None       
            

    def create_initial_state(self):
        """ returns the initial state of othe problem
        """
        #TODO: implement this function. 
        return None

    def is_goal(self, a_state:State):
        """Returns True if the given state is a goal state"""
        #TODO: implement this function. 
        return False

    def actions(self, a_state:State):
        """ Returns all the actions that are legal in the given state.
            
        """
        #TODO: implement this function. 
        return None

    def result(self, a_state:State, an_action):
        """Given a state and an action, return the resulting state.
           
        """
        #TODO: implement this function. 
    
        return None



            
# end of file

